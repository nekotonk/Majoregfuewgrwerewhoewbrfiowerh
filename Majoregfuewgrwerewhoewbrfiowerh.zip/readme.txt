Majoregfuewgrwerewhoewbrfiowerh is a GDI Malware made by nekotonk
Do not under any circumstances use this maliciously.
Programming Language: C++

Don't run on real pc!

Run on vitualbox vs vmware